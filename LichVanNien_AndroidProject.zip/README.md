Lịch Vạn Niên - Android WebView wrapper
======================================
Instructions:
1) Build the React app: npm install && npm run build
2) Copy the contents of the build output (dist) into app/src/main/assets/www
   You can use the provided copy_dist.sh script.
3) Open this folder in Android Studio (use Gradle plugin compatible version).
4) Build > Build APK(s)
