Place your built Vite 'dist' contents here under this folder (www).
Steps to build and package:
1) On your machine, open the React source folder (the ZIP you uploaded).
2) Run: npm install
3) Run: npm run build
4) Copy the generated 'dist' folder contents into app/src/main/assets/www/
   (so index.html and assets are at app/src/main/assets/www/index.html etc)
5) Open this project in Android Studio and Build > Build APK(s).
